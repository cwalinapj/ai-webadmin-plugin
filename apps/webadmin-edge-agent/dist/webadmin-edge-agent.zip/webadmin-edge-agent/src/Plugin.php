<?php

namespace WebAdminEdgeAgent;

use WebAdminEdgeAgent\Admin\Menu;
use WebAdminEdgeAgent\Api\Client;
use WebAdminEdgeAgent\Api\Endpoints\Heartbeat;
use WebAdminEdgeAgent\Command\Dispatcher;
use WebAdminEdgeAgent\Storage\JobStore;
use WebAdminEdgeAgent\Storage\Logger;
use WebAdminEdgeAgent\Storage\Options;
use WebAdminEdgeAgent\Storage\TabState;

class Plugin
{
    public const CRON_HOOK = 'webadmin_edge_agent_cron_heartbeat';

    public const CRON_SCHEDULE = 'webadmin_edge_agent_every_5_minutes';

    private static ?self $instance = null;

    private Options $options;

    private Logger $logger;

    private Client $client;

    private Heartbeat $heartbeatEndpoint;

    private Menu $menu;

    private TabState $tabState;

    private JobStore $jobStore;

    private Dispatcher $dispatcher;

    public static function boot(): void
    {
        if (self::$instance instanceof self) {
            return;
        }

        self::$instance = new self();
        self::$instance->registerHooks();
    }

    private function __construct()
    {
        $this->options = new Options();
        $this->logger = new Logger($this->options);
        $this->tabState = new TabState();
        $this->jobStore = new JobStore();
        $this->dispatcher = new Dispatcher($this->logger, $this->jobStore);
        $this->client = new Client($this->options, $this->logger);
        $this->heartbeatEndpoint = new Heartbeat(
            $this->options,
            $this->logger,
            $this->client,
            $this->dispatcher,
            $this->tabState,
            $this->jobStore
        );
        $this->menu = new Menu($this->options, $this->logger, $this->heartbeatEndpoint, $this->tabState, $this->jobStore);
    }

    private function registerHooks(): void
    {
        $this->menu->register();

        add_filter('cron_schedules', [$this, 'registerCronSchedule']);
        add_action('init', [$this, 'ensureCronScheduled']);
        add_action(self::CRON_HOOK, [$this, 'runScheduledHeartbeat']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
    }

    /**
     * @param array<string, array<string, mixed>> $schedules
     * @return array<string, array<string, mixed>>
     */
    public function registerCronSchedule(array $schedules): array
    {
        return self::registerCronScheduleStatic($schedules);
    }

    public function ensureCronScheduled(): void
    {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 300, self::CRON_SCHEDULE, self::CRON_HOOK);
        }
    }

    public function runScheduledHeartbeat(): void
    {
        $this->heartbeatEndpoint->send('cron');
    }

    public static function activate(): void
    {
        add_filter('cron_schedules', [self::class, 'registerCronScheduleStatic']);
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 300, self::CRON_SCHEDULE, self::CRON_HOOK);
        }
        remove_filter('cron_schedules', [self::class, 'registerCronScheduleStatic']);
    }

    public static function deactivate(): void
    {
        while ($timestamp = wp_next_scheduled(self::CRON_HOOK)) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    /**
     * @param array<string, array<string, mixed>> $schedules
     * @return array<string, array<string, mixed>>
     */
    public static function registerCronScheduleStatic(array $schedules): array
    {
        $schedules[self::CRON_SCHEDULE] = [
            'interval' => 300,
            'display' => 'Every 5 Minutes (WebAdmin Edge Agent)',
        ];

        return $schedules;
    }

    public function enqueueAssets(string $hook): void
    {
        if ($hook !== 'toplevel_page_webadmin-edge-agent') {
            return;
        }

        wp_enqueue_style(
            'webadmin-edge-agent-admin',
            plugin_dir_url(WEBADMIN_EDGE_AGENT_FILE) . 'assets/admin.css',
            [],
            WEBADMIN_EDGE_AGENT_VERSION
        );

        wp_enqueue_script(
            'webadmin-edge-agent-admin',
            plugin_dir_url(WEBADMIN_EDGE_AGENT_FILE) . 'assets/admin.js',
            [],
            WEBADMIN_EDGE_AGENT_VERSION,
            true
        );
    }
}

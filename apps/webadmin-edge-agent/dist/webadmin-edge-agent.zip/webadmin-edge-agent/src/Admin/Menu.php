<?php

namespace WebAdminEdgeAgent\Admin;

use WebAdminEdgeAgent\Admin\Tabs\AnalyticsTab;
use WebAdminEdgeAgent\Admin\Tabs\DnsEmailTab;
use WebAdminEdgeAgent\Admin\Tabs\LeadsTab;
use WebAdminEdgeAgent\Admin\Tabs\SecurityTab;
use WebAdminEdgeAgent\Admin\Tabs\UptimeTab;
use WebAdminEdgeAgent\Api\Endpoints\Heartbeat;
use WebAdminEdgeAgent\Storage\JobStore;
use WebAdminEdgeAgent\Storage\Logger;
use WebAdminEdgeAgent\Storage\Options;
use WebAdminEdgeAgent\Storage\TabState;

class Menu
{
    private Options $options;

    private Logger $logger;

    private Heartbeat $heartbeat;

    private TabState $tabState;

    private JobStore $jobStore;

    public function __construct(
        Options $options,
        Logger $logger,
        Heartbeat $heartbeat,
        TabState $tabState,
        JobStore $jobStore
    ) {
        $this->options = $options;
        $this->logger = $logger;
        $this->heartbeat = $heartbeat;
        $this->tabState = $tabState;
        $this->jobStore = $jobStore;
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'registerMenu']);
        add_action('admin_post_webadmin_edge_agent_save_settings', [$this, 'handleSaveSettings']);
        add_action('admin_post_webadmin_edge_agent_send_heartbeat', [$this, 'handleSendHeartbeat']);
        add_action('admin_post_webadmin_edge_agent_run_tab_sync', [$this, 'handleRunTabSync']);
    }

    public function registerMenu(): void
    {
        add_menu_page(
            'WebAdmin Edge Agent',
            'WebAdmin Edge Agent',
            'manage_options',
            'webadmin-edge-agent',
            [$this, 'renderPage'],
            'dashicons-shield-alt',
            56
        );
    }

    public function handleSaveSettings(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'webadmin-edge-agent'));
        }

        check_admin_referer('webadmin_edge_agent_save_settings', 'webadmin_edge_agent_nonce');

        $input = [
            'worker_base_url' => isset($_POST['worker_base_url']) ? wp_unslash($_POST['worker_base_url']) : '',
            'plugin_id' => isset($_POST['plugin_id']) ? wp_unslash($_POST['plugin_id']) : '',
            'site_id' => isset($_POST['site_id']) ? wp_unslash($_POST['site_id']) : '',
            'domain' => isset($_POST['domain']) ? wp_unslash($_POST['domain']) : '',
            'plan' => isset($_POST['plan']) ? wp_unslash($_POST['plan']) : '',
            'timezone' => isset($_POST['timezone']) ? wp_unslash($_POST['timezone']) : '',
            'shared_secret' => isset($_POST['shared_secret']) ? wp_unslash($_POST['shared_secret']) : '',
            'capability_token_uptime' => isset($_POST['capability_token_uptime']) ? wp_unslash($_POST['capability_token_uptime']) : '',
        ];

        $this->options->saveSettings($input);
        $this->logger->log('info', 'Connection settings updated');
        add_settings_error('webadmin-edge-agent', 'settings-saved', 'Settings saved.', 'updated');

        $this->redirectWithTab('uptime');
    }

    public function handleSendHeartbeat(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'webadmin-edge-agent'));
        }

        check_admin_referer('webadmin_edge_agent_send_heartbeat', 'webadmin_edge_agent_heartbeat_nonce');

        $result = $this->heartbeat->send('manual');
        if (!empty($result['ok'])) {
            add_settings_error('webadmin-edge-agent', 'heartbeat-ok', 'Heartbeat sent successfully.', 'updated');
        } else {
            $message = 'Heartbeat failed.';
            if (!empty($result['error'])) {
                $message .= ' ' . sanitize_text_field((string)$result['error']);
            }
            add_settings_error('webadmin-edge-agent', 'heartbeat-error', $message, 'error');
        }

        $this->redirectWithTab('uptime');
    }

    public function handleRunTabSync(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized', 'webadmin-edge-agent'));
        }

        check_admin_referer('webadmin_edge_agent_run_tab_sync', 'webadmin_edge_agent_tab_sync_nonce');

        $tab = isset($_POST['tab']) ? sanitize_key((string)wp_unslash($_POST['tab'])) : '';
        $tabs = $this->tabs();
        if (!isset($tabs[$tab])) {
            add_settings_error('webadmin-edge-agent', 'tab-run-invalid', 'Invalid tab selected.', 'error');
            $this->redirectWithTab('uptime');
        }

        $this->runTabSync($tab);
        $this->redirectWithTab($tab);
    }

    public function renderPage(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $tabs = $this->tabs();
        $currentTab = isset($_GET['tab']) ? sanitize_key((string)wp_unslash($_GET['tab'])) : 'uptime';
        if (!isset($tabs[$currentTab])) {
            $currentTab = 'uptime';
        }

        $settings = $this->options->getSettings();
        settings_errors('webadmin-edge-agent');

        echo '<div class="wrap webadmin-edge-agent">';
        echo '<h1>WebAdmin Edge Agent</h1>';
        echo '<h2 class="nav-tab-wrapper">';

        foreach ($tabs as $key => $tabData) {
            $class = $key === $currentTab ? 'nav-tab nav-tab-active' : 'nav-tab';
            $url = admin_url('admin.php?page=webadmin-edge-agent&tab=' . $key);
            echo '<a href="' . esc_url($url) . '" class="' . esc_attr($class) . '">' . esc_html((string)$tabData['label']) . '</a>';
        }

        echo '</h2>';

        $tabObject = $tabs[$currentTab]['instance'];
        if ($tabObject instanceof UptimeTab) {
            $tabObject->render([
                'settings' => $settings,
                'shared_secret_configured' => $this->options->hasSecret('shared_secret'),
                'capability_token_uptime_configured' => $this->options->hasSecret('capability_token_uptime'),
            ]);
        }

        if ($tabObject instanceof SecurityTab) {
            $tabObject->render();
        }

        if ($tabObject instanceof AnalyticsTab) {
            $tabObject->render();
        }

        if ($tabObject instanceof DnsEmailTab) {
            $tabObject->render();
        }

        if ($tabObject instanceof LeadsTab) {
            $tabObject->render();
        }

        $this->renderTabShell($currentTab, (string)$tabs[$currentTab]['label']);
        $this->renderLogs();

        echo '</div>';
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function tabs(): array
    {
        return [
            'uptime' => ['label' => 'Uptime & Performance', 'instance' => new UptimeTab()],
            'security' => ['label' => 'Security', 'instance' => new SecurityTab()],
            'analytics' => ['label' => 'Analytics & Reporting', 'instance' => new AnalyticsTab()],
            'dns-email' => ['label' => 'Domain, DNS & Email', 'instance' => new DnsEmailTab()],
            'leads' => ['label' => 'Forms, Leads & Integrations', 'instance' => new LeadsTab()],
        ];
    }

    private function runTabSync(string $tab): void
    {
        if ($tab === 'uptime') {
            $result = $this->heartbeat->send('manual_run');
            if (!empty($result['ok'])) {
                add_settings_error('webadmin-edge-agent', 'tab-run-ok', 'Run now completed for Uptime & Performance.', 'updated');
            } else {
                add_settings_error('webadmin-edge-agent', 'tab-run-error', 'Run now failed for Uptime & Performance.', 'error');
            }
            return;
        }

        $this->tabState->recordSync($tab, 'ok', 'Manual run executed.');
        $this->tabState->addFinding(
            $tab,
            'info',
            'Manual check completed',
            'Milestone 1 shell run executed; endpoint-specific automation comes in next milestones.'
        );
        $this->jobStore->add($tab, 'manual_sync', 'completed', 0.0, true, ['source' => 'manual']);
        $this->logger->log('info', 'Manual tab sync executed', ['tab' => $tab]);

        add_settings_error('webadmin-edge-agent', 'tab-run-ok', 'Run now completed.', 'updated');
    }

    private function renderTabShell(string $tab, string $tabLabel): void
    {
        $state = $this->tabState->get($tab);
        $findings = $this->tabState->recentFindings($tab, 10);
        $jobs = $this->jobStore->recentByTab($tab, 10);

        echo '<hr/>';
        echo '<h2>' . esc_html($tabLabel) . ' Sync Shell</h2>';

        $lastSyncAt = (int)($state['last_sync_at'] ?? 0);
        $lastSyncStatus = (string)($state['last_sync_status'] ?? 'never');
        $lastSyncMessage = (string)($state['last_sync_message'] ?? '');

        echo '<p><strong>Last sync:</strong> ';
        if ($lastSyncAt > 0) {
            echo esc_html(gmdate('Y-m-d H:i:s', $lastSyncAt) . ' UTC');
        } else {
            echo esc_html('never');
        }
        echo ' (' . esc_html($lastSyncStatus) . ')';
        if ($lastSyncMessage !== '') {
            echo ' - ' . esc_html($lastSyncMessage);
        }
        echo '</p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('webadmin_edge_agent_run_tab_sync', 'webadmin_edge_agent_tab_sync_nonce');
        echo '<input type="hidden" name="action" value="webadmin_edge_agent_run_tab_sync" />';
        echo '<input type="hidden" name="tab" value="' . esc_attr($tab) . '" />';
        echo '<p><button type="submit" class="button">Run Now</button></p>';
        echo '</form>';

        echo '<h3>Recent Findings</h3>';
        if (empty($findings)) {
            echo '<p>No findings recorded yet.</p>';
        } else {
            echo '<table class="widefat striped">';
            echo '<thead><tr><th>Timestamp (UTC)</th><th>Severity</th><th>Title</th><th>Detail</th></tr></thead>';
            echo '<tbody>';
            foreach ($findings as $finding) {
                if (!is_array($finding)) {
                    continue;
                }
                echo '<tr>';
                echo '<td>' . esc_html((string)($finding['ts'] ?? '')) . '</td>';
                echo '<td>' . esc_html((string)($finding['severity'] ?? 'info')) . '</td>';
                echo '<td>' . esc_html((string)($finding['title'] ?? '')) . '</td>';
                echo '<td>' . esc_html((string)($finding['detail'] ?? '')) . '</td>';
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
        }

        echo '<h3>Recent Jobs (Shared Job Table)</h3>';
        if (empty($jobs)) {
            echo '<p>No jobs recorded for this tab yet.</p>';
        } else {
            echo '<table class="widefat striped">';
            echo '<thead><tr><th>Timestamp (UTC)</th><th>Job ID</th><th>Type</th><th>Status</th><th>Risk</th><th>Dry Run</th><th>Context</th></tr></thead>';
            echo '<tbody>';
            foreach ($jobs as $job) {
                if (!is_array($job)) {
                    continue;
                }
                $context = isset($job['context']) && is_array($job['context']) ? wp_json_encode($job['context']) : '';
                echo '<tr>';
                echo '<td>' . esc_html((string)($job['ts'] ?? '')) . '</td>';
                echo '<td><code>' . esc_html((string)($job['id'] ?? '')) . '</code></td>';
                echo '<td>' . esc_html((string)($job['type'] ?? '')) . '</td>';
                echo '<td>' . esc_html((string)($job['status'] ?? '')) . '</td>';
                echo '<td>' . esc_html((string)($job['risk_score'] ?? '0')) . '</td>';
                echo '<td>' . (!empty($job['dry_run']) ? 'yes' : 'no') . '</td>';
                echo '<td><code>' . esc_html((string)$context) . '</code></td>';
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
        }
    }

    private function renderLogs(): void
    {
        $events = $this->logger->recent(100);

        echo '<hr/>';
        echo '<h2>Last 100 Events</h2>';

        if (empty($events)) {
            echo '<p>No events recorded yet.</p>';
            return;
        }

        echo '<table class="widefat striped">';
        echo '<thead><tr><th>Timestamp (UTC)</th><th>Level</th><th>Message</th><th>Context</th></tr></thead>';
        echo '<tbody>';

        foreach ($events as $event) {
            if (!is_array($event)) {
                continue;
            }
            $context = isset($event['context']) && is_array($event['context']) ? wp_json_encode($event['context']) : '';
            echo '<tr>';
            echo '<td>' . esc_html((string)($event['ts'] ?? '')) . '</td>';
            echo '<td>' . esc_html((string)($event['level'] ?? 'info')) . '</td>';
            echo '<td>' . esc_html((string)($event['message'] ?? '')) . '</td>';
            echo '<td><code>' . esc_html((string)$context) . '</code></td>';
            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';
    }

    private function redirectWithTab(string $tab): void
    {
        $url = admin_url('admin.php?page=webadmin-edge-agent&tab=' . rawurlencode($tab));
        wp_safe_redirect($url);
        exit;
    }
}

<?php

namespace WebAdminEdgeAgent\Admin\Tabs;

class AnalyticsTab
{
    public function render(): void
    {
        ?>
        <h2>Analytics &amp; Reporting</h2>
        <p>Signals + jobs + commands: analytics config sync and event validation drive monthly insight jobs.</p>
        <ul>
          <li>GA4/Search Console/call-tracking sync</li>
          <li>Event and goal validation checks</li>
          <li>Monthly KPI insights and action summaries</li>
        </ul>
        <?php
    }
}

<?php

namespace WebAdminEdgeAgent\Storage;

class Options
{
    public const OPTION_KEY = 'webadmin_edge_agent_settings';

    public const LOG_KEY = 'webadmin_edge_agent_logs';

    /**
     * @return array<string, mixed>
     */
    public function defaults(): array
    {
        $domain = (string)parse_url(home_url(), PHP_URL_HOST);
        $timezone = wp_timezone_string();
        if ($timezone === '') {
            $timezone = 'UTC';
        }

        return [
            'worker_base_url' => '',
            'plugin_id' => '',
            'site_id' => '',
            'domain' => $domain,
            'plan' => 'free',
            'timezone' => $timezone,
            'shared_secret' => '',
            'capability_token_uptime' => '',
            'last_heartbeat_at' => 0,
            'last_heartbeat_status' => 'never',
            'last_heartbeat_message' => '',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function getSettings(): array
    {
        $stored = get_option(self::OPTION_KEY, []);
        if (!is_array($stored)) {
            $stored = [];
        }

        return array_merge($this->defaults(), $stored);
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    public function saveSettings(array $input): array
    {
        $current = $this->getSettings();

        $next = [
            'worker_base_url' => isset($input['worker_base_url']) ? esc_url_raw(trim((string)$input['worker_base_url'])) : (string)$current['worker_base_url'],
            'plugin_id' => isset($input['plugin_id']) ? sanitize_text_field(trim((string)$input['plugin_id'])) : (string)$current['plugin_id'],
            'site_id' => isset($input['site_id']) ? sanitize_text_field(trim((string)$input['site_id'])) : (string)$current['site_id'],
            'domain' => isset($input['domain']) ? sanitize_text_field(trim((string)$input['domain'])) : (string)$current['domain'],
            'plan' => isset($input['plan']) ? sanitize_text_field(trim((string)$input['plan'])) : (string)$current['plan'],
            'timezone' => isset($input['timezone']) ? sanitize_text_field(trim((string)$input['timezone'])) : (string)$current['timezone'],
            'shared_secret' => (string)$current['shared_secret'],
            'capability_token_uptime' => (string)$current['capability_token_uptime'],
            'last_heartbeat_at' => (int)$current['last_heartbeat_at'],
            'last_heartbeat_status' => sanitize_text_field((string)$current['last_heartbeat_status']),
            'last_heartbeat_message' => sanitize_text_field((string)$current['last_heartbeat_message']),
        ];

        if (isset($input['shared_secret']) && trim((string)$input['shared_secret']) !== '') {
            $next['shared_secret'] = $this->encryptSecret((string)$input['shared_secret']);
        }

        if (isset($input['capability_token_uptime']) && trim((string)$input['capability_token_uptime']) !== '') {
            $next['capability_token_uptime'] = $this->encryptSecret((string)$input['capability_token_uptime']);
        }

        update_option(self::OPTION_KEY, $next, false);

        return $next;
    }

    /**
     * @return array<string, mixed>
     */
    public function updateHeartbeatStatus(string $status, string $message): array
    {
        $settings = $this->getSettings();
        $settings['last_heartbeat_at'] = time();
        $settings['last_heartbeat_status'] = sanitize_text_field($status);
        $settings['last_heartbeat_message'] = sanitize_text_field($message);

        update_option(self::OPTION_KEY, $settings, false);

        return $settings;
    }

    public function getDecryptedSecret(string $key): string
    {
        $settings = $this->getSettings();
        $raw = (string)($settings[$key] ?? '');
        if ($raw === '') {
            return '';
        }

        return $this->decryptSecret($raw);
    }

    public function hasSecret(string $key): bool
    {
        $settings = $this->getSettings();

        return !empty($settings[$key]);
    }

    private function encryptSecret(string $plaintext): string
    {
        $value = trim($plaintext);
        if ($value === '') {
            return '';
        }

        $key = $this->encryptionKey();
        if ($key === null || !function_exists('openssl_encrypt')) {
            return 'plain:v1:' . base64_encode($value);
        }

        try {
            $iv = random_bytes(16);
        } catch (\Throwable $exception) {
            return 'plain:v1:' . base64_encode($value);
        }

        $ciphertext = openssl_encrypt($value, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        if (!is_string($ciphertext) || $ciphertext === '') {
            return 'plain:v1:' . base64_encode($value);
        }

        return 'enc:v1:' . base64_encode($iv) . ':' . base64_encode($ciphertext);
    }

    private function decryptSecret(string $stored): string
    {
        if (strpos($stored, 'enc:v1:') === 0) {
            $parts = explode(':', $stored);
            if (count($parts) !== 4) {
                return '';
            }

            $key = $this->encryptionKey();
            if ($key === null || !function_exists('openssl_decrypt')) {
                return '';
            }

            $iv = base64_decode((string)$parts[2], true);
            $ciphertext = base64_decode((string)$parts[3], true);
            if (!is_string($iv) || !is_string($ciphertext) || strlen($iv) !== 16) {
                return '';
            }

            $plaintext = openssl_decrypt($ciphertext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
            if (!is_string($plaintext)) {
                return '';
            }

            return $plaintext;
        }

        if (strpos($stored, 'plain:v1:') === 0) {
            $decoded = base64_decode(substr($stored, 9), true);
            if (is_string($decoded)) {
                return $decoded;
            }
        }

        return '';
    }

    private function encryptionKey(): ?string
    {
        $material = '';
        $constants = ['AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY'];
        foreach ($constants as $constant) {
            if (defined($constant)) {
                $material .= (string)constant($constant);
            }
        }

        if ($material === '') {
            return null;
        }

        return hash('sha256', $material, true);
    }
}
